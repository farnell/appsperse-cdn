//
//  ACPromotionInterstitial.h
//  AppsperseClient
//
//  Created by Matthew Farnell on 10/24/11.
//  (c) 2011 Appsperse. All rights reserved.
//

//  Example Usage:
//
//  [[ACPromotionInterstitial sharedACPromotionInterstitial] showInterstitial:self animated:YES withDelegate:self];


#import <UIKit/UIKit.h>

@protocol ACPromotionInterstitialDelegate <NSObject>

@optional

// Sent when a promotion request has been successfully recieved.
- (void)acPromotionInterstitialDidReceivePromotion;

// Sent when a promotion request failed. This is typically because no network connection was available or no promotions were available (i.e. no fill).
- (void)acPromotionInterstitialDidFailToReceiveWithError:(NSError *)error;

// Sent just before dismissing a full screen promotions view 
- (void)acPromotionInterstitialWillDismissScreen;

// Note: after this returns the app will end or go into the background
- (void)acPromotionInterstitialDidClickOnPromotion;

@end


@interface ACPromotionInterstitial : NSObject {
    
}

@property (assign) id<ACPromotionInterstitialDelegate> delegate;

+ (ACPromotionInterstitial *)sharedACPromotionInterstitial;

- (void)showInterstitial:(UIViewController *)parentController animated:(BOOL)animate withDelegate:(id<ACPromotionInterstitialDelegate>)delegate;


@end
