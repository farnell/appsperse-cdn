//
//  ACPromotionBannerView.h
//  AppsperseClient
//
//  Created by Matthew Farnell on 9/28/11.
//  2011 Appsperse. All rights reserved.
//

//  Example Usage: To attach a banner view
//
//  ACPromotionBannerView *promotionsView = [[ACPromotionBannerView alloc] initWithPosition:CGPointMake(0, 0)];
//  [promotionsView setDelegate:self];    
//  [[self view] addSubview:promotionView];
//  [promotionView requestPromotion];    


#import <UIKit/UIKit.h>

// iPhone and iPod Touch ad size.
#define ACP_SIZE_320x50     CGSizeMake(320, 50)

@class ACPromotionBannerView;

@protocol ACPromotionBannerViewDelegate <NSObject>

@optional

// Sent when a promotion request has been successfully recieved.
- (void)acPromotionBannerViewDidReceivePromotion:(ACPromotionBannerView *)acPromotionView;

//- (void)acPromotionBannerViewNoPromotionsAvailable:(ACPromotionBannerView *)acPromotionView;

// Sent when a promotion request failed. This is typically because no network connection was available or no promotions were available (i.e. no fill).
- (void)acPromotionBannerViewDidFailToReceivePromotion:(ACPromotionBannerView *)acPromotionView withError:(NSError *)error;

// Note: after this returns the app will end or go into the background
- (void)acPromotionBannerViewDidClickOnPromotion:(ACPromotionBannerView *)acPromotionView;

@end


@interface ACPromotionBannerView : UIView {

    id<ACPromotionBannerViewDelegate> delegate;
}

@property (nonatomic, assign) id<ACPromotionBannerViewDelegate> delegate;

- (void)requestPromotion;

- (id)initWithPosition:(CGPoint)point;


@end
