//
//  ACPromotionSettings.h
//  AppsperseClient
//
//  Created by Matt Farnell
//  Copyright (c) 2011 Appsperse. All rights reserved.
//
//  Example Usage: (Optimal placement is in the application launch.)
//
//- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
//{
//    self.window.rootViewController = self.viewController;
//    [self.window makeKeyAndVisible];
//    
//    [ACPromotionSettings setAppKey:@"REPLACE_THIS_TEXT_WITH_YOUR_APP_KEY"];
//    
//    return YES;
//}

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface ACPromotionSettings : NSObject

+ (void)setAppKey:(NSString *)appKey;

+ (NSString *)appKey;

+ (NSString *)sdkVersion;

// Optional Display Settings

// banner
+ (void)setDisplayBannerGradient:(BOOL)value;
+ (void)setDisplayBannerBorder:(BOOL)value;

+ (BOOL)displayBannerGradient;
+ (BOOL)displayBannerBorder;

// wall
+ (void)setWallTitle:(NSString *)title;
+ (void)setWallBackgroundColor:(UIColor *)color;
+ (void)setWallNavigationBarTintColor:(UIColor *)color;

+ (NSString *)wallTitle;
+ (UIColor *)wallBackgroundColor;
+ (UIColor *)wallNavigationBarTintColor;

// interstitial
+ (void)setInterstitialTitle:(NSString *)title;
+ (void)setInterstitialBackgroundColor:(UIColor *)color;
+ (void)setInterstitialBorderColor:(UIColor *)color;
+ (NSString *)interstitialTitle;
+ (UIColor *)interstitialBackgroundColor;
+ (UIColor *)interstitialBorderColor;


@end

