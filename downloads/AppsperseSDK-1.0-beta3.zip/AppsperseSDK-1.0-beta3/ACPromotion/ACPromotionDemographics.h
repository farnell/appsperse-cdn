//
//  ACPromotionDemographics.h
//  AppsperseClient
//
//  Created by Hugo Troche on 11/1/11.
//  Copyright (c) 2011 Appsperse. All rights reserved.
//
//  Example Usage:
//  If a user does anything of high value (e.g. in-app purchase). 
//  This will enable us to direct promotions to the demographics which are the most valuable for this app.
//  [ACPromotionDemographics trackHighValueMarker];
//
//  If you want to track categorize your high value users
//  [ACPromotionDemographics trackHighValueMarker:@"typeA"];
//
//  Set any Demographic information you have. It will enable us to target your promotions more effectively.
//  [ACPromotionDemographics setAge:10];
//  [ACPromotionDemographics setDateOfBirth:[NSDate date]];
//  [ACPromotionDemographics setEducation:ACEducationCollege];
//  [ACPromotionDemographics setEthnicity:ACEthnicityAsian];
//  [ACPromotionDemographics setGender:ACGenderMale];
//  [ACPromotionDemographics setMaritialStatus:ACMaritalSingle];
//  [ACPromotionDemographics setReligion:ACReligionChristian];
//  [ACPromotionDemographics setLocationText:@"Bunbury"];
//  [ACPromotionDemographics setLocationWithLatitude:37.0 longitude:123.0 accuracy:5.2];
//  [ACPromotionDemographics addKeyword:@"keyword1"];
//  [ACPromotionDemographics addKeyword:@"keyword2"];
//  [ACPromotionDemographics addKeyword:@"keyword3"];


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

typedef enum {
    ACGenderUnknown,
    ACGenderFemale,
    ACGenderMale
} ACGender;

typedef enum {
	ACEducationUnknown,
	ACEducationHighSchool,
	ACEducationCollege,
	ACEducationBachelorsDegree,
	ACEducationMastersDegree,
	ACEducationDoctoralDegree
} ACEducation;

typedef enum {
	ACEthnicityUnknown,
	ACEthnicityMixed,
	ACEthnicityAsian,
	ACEthnicityBlack,
	ACEthnicityHispanic,
	ACEthnicityAmerican,
	ACEthnicityWhite
} ACEthnicity;

typedef enum {
	ACReligionUnknown,
	ACReligionBuddhism,
	ACReligionChristian,
    ACReligionHinduism,
	ACReligionIslam,
	ACReligionJudaism,
	ACReligionUnaffiliated,
	ACReligionOther
} ACReligion;

typedef enum {
	ACMaritalUnknown,
	ACMaritalSingle,
	ACMaritalMarried,
} ACMaritalStatus;



@interface ACPromotionDemographics : NSObject

// Call this when the user does some action which you consider high value.
// e.g. in-app purchase, filled out a survey. 
// Once we know what type of users are high value for your app we can direct promotions to similar users
+ (void)trackHighValueMarker;

+ (void)trackHighValueMarker:(NSString *)markerLabel;

+ (void)setGender:(ACGender)gender;

+ (void)setEducation:(ACEducation)education;

+ (void)setEthnicity:(ACEthnicity)ethnicity;

+ (void)setReligion:(ACReligion)ethnicity;

+ (void)setMaritialStatus:(ACMaritalStatus)maritalStatus;

+ (void)setDateOfBirth:(NSDate *)dob;

// If you have age as a number instead of a date object
+ (void)setAge:(int)age;

// If you already use location in your app set it here for more relelvent targeting.
+ (void)setLocationWithLatitude:(CGFloat)latitude longitude:(CGFloat)longitude accuracy:(CGFloat)accuracyInMeters;

// If you don't use location but have some type of location text such as city, zipcode eg. @"San Francisco", @"94105"
+ (void)setLocationText:(NSString *)locationText;

// add any relelvent keywords eg. @"sport", @"food"
+ (void)addKeyword:(NSString *)keyword;

// clears any previously set keywords
+ (void)clearKeywords;


@end
