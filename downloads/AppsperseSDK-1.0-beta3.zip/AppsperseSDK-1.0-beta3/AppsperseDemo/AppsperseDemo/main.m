//
//  main.m
//  AppsperseDemo
//
//  Created by Matthew Farnell on 10/30/11.
//  Copyright (c) 2011 MeMap. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppsperseDemoAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppsperseDemoAppDelegate class]));
    }
}
