//
//  AppsperseDemoAppDelegate.h
//  AppsperseDemo
//
//  Created by Matthew Farnell on 10/30/11.
//  Copyright (c) 2011 MeMap. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppsperseDemoViewController;

@interface AppsperseDemoAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) AppsperseDemoViewController *viewController;

@end
