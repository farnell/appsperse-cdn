//
//  LTVBurstlyUtil.m
//  LTVBurstlyUtil
//
//  Created by Hugo Troche on 6/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#define DNL_OK @"DNL_OK"
#define DNL_ERR_DLTRK @"DNL_ERR_DLTRK"
#define BURSTLY_URL @"http://req.appads.com/scripts/ConfirmDownload.aspx"
#define DOWNLOAD_TRACKED @"appsperse.burstly"

#import "LTVBurstlyUtil.h"
#include <sys/socket.h>
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>

#import <CommonCrypto/CommonDigest.h>
#import "LTVClient.h"


@implementation LTVBurstlyUtil

- (void) trackBurstlyDownload {
    NSString *tracked = [[NSUserDefaults standardUserDefaults] objectForKey:DOWNLOAD_TRACKED];
    if(tracked != nil)
        return;
    if(receivedData != nil) {
        [receivedData release];
        receivedData = nil;
    }
    receivedData = [NSMutableData data];
    [receivedData retain];
    NSString *url = [NSString stringWithFormat:@"%@?bundleId=%@&mac=%@&distribution=true", BURSTLY_URL, [LTVBurstlyUtil deviceBundleIdentifier], [LTVBurstlyUtil macaddress]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]
                                                           cachePolicy:NSURLRequestReloadIgnoringCacheData
                                                       timeoutInterval:60.0];
	[request setHTTPMethod:@"GET"];
    
    [NSURLConnection connectionWithRequest:request delegate:self];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    [self autorelease];
}


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [receivedData appendData:data];
}


- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSString *response = [[NSString alloc] initWithBytes:[receivedData bytes] length:[receivedData length] encoding:NSUTF8StringEncoding];
    if([response isEqualToString:DNL_OK]) {
        [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:DOWNLOAD_TRACKED];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [LTVClient trackBurstly];
    } else if([response isEqualToString:DNL_ERR_DLTRK]) {
        [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:DOWNLOAD_TRACKED];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    [self autorelease];
}

+ (NSString *) macaddress

{
    int mib[6];
    
    size_t len;
    char *buf;
    unsigned char *ptr;
    
    struct if_msghdr *ifm;
    struct sockaddr_dl *sdl;
    
    
    mib[0] = CTL_NET;
    
    mib[1] = AF_ROUTE;
    
    mib[2] = 0;
    
    mib[3] = AF_LINK;
    
    mib[4] = NET_RT_IFLIST;
    
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        
        printf("Error: if_nametoindex error\n");
        
        return NULL;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        
        printf("Error: sysctl, take 1\n");
        
        return NULL;
    }
    
    if ((buf = malloc(len)) == NULL) {
        
        printf("Could not allocate memory. error!\n");
        
        return NULL;
    }
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        
        printf("Error: sysctl, take 2");
        return NULL;
    }
    
    ifm = (struct if_msghdr *)buf;
    
    sdl = (struct sockaddr_dl *)(ifm + 1);
    
    ptr = (unsigned char *)LLADDR(sdl);
    
    NSString *outstring = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X",
                           
                           *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    
    // NSString *outstring = [NSString stringWithFormat:@"%02X%02X%02X%02X%02X%02X",
    // *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    free(buf);
    
    return [LTVBurstlyUtil hashMacAddress:outstring];
    
}

+ (NSString *) hashMacAddress:(NSString *) macAddress {
    const char *cstr = [macAddress cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:macAddress.length];
    
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    
    CC_SHA1(data.bytes, data.length, digest);
    
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return output;
}

+ (NSString *)deviceBundleIdentifier {
    return [[NSBundle mainBundle] bundleIdentifier];
}

- (void) dealloc {
    [receivedData release];
    [super dealloc];
}

@end
