//
//  LTVBurstlyUtil.h
//  LTVBurstlyUtil
//
//  Created by Hugo Troche on 6/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LTVBurstlyUtil : NSObject <NSURLConnectionDataDelegate> {
    NSMutableData *receivedData;
}

+ (NSString *) macaddress;
+ (NSString *)deviceBundleIdentifier;
+ (NSString *) hashMacAddress:(NSString *) macAddress;

- (void) trackBurstlyDownload;

@end
