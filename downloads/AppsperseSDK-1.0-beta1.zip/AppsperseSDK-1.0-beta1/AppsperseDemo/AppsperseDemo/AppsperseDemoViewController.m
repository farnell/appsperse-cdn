//
//  AppsperseDemoViewController.m
//  AppsperseDemo
//
//  Created by Matthew Farnell on 10/30/11.
//  Copyright (c) 2011 MeMap. All rights reserved.
//

#import "AppsperseDemoViewController.h"

@implementation AppsperseDemoViewController

@synthesize promotionView;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void) viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    UIButton *buttonWall = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    buttonWall.frame = CGRectMake(30, 50, 260, 38);
    [buttonWall setTitle:@"Promotion Wall" forState:0];
    [buttonWall addTarget:self action:@selector(buttonShowOfferWallAction:) forControlEvents:UIControlEventTouchUpInside];
    [[self view] addSubview: buttonWall ];
    
    UIButton *buttonView = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    buttonView.frame = CGRectMake(30, 100, 260, 38);
    [buttonView setTitle:@"Show/Refresh Banner View" forState:0];
    [buttonView addTarget:self action:@selector(buttonShowBannerViewAction:) forControlEvents:UIControlEventTouchUpInside];
    [[self view] addSubview: buttonView ];
    
    UIButton *buttonInterstitial = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    buttonInterstitial.frame = CGRectMake(30, 150, 260, 38);
    [buttonInterstitial setTitle:@"Show/Refresh Interstitial View" forState:0];
    [buttonInterstitial addTarget:self action:@selector(buttonShowInterstitialViewAction:) forControlEvents:UIControlEventTouchUpInside];
    [[self view] addSubview: buttonInterstitial ];
    
}


- (void) buttonShowOfferWallAction:(id) sender {
    //NSLog(@"buttonShowOfferWallAction");    
    [[ACPromotionWall sharedACPromotionWall] showPromotions:self withDelegate:self];
}

- (void) buttonShowInterstitialViewAction:(id) sender {
    //NSLog(@"buttonShowInterstitialViewAction");    
    [[ACPromotionInterstitial sharedACPromotionInterstitial] showInterstitial:self withDelegate:self];
}


- (void) buttonShowBannerViewAction:(id) sender {
    //NSLog(@"buttonShowBannerViewAction");
    if (!promotionView) {
        ACPromotionBannerView *newPromotionsView = [[ACPromotionBannerView alloc] initWithPosition:CGPointMake(0, self.view.frame.size.height-50)];
        [newPromotionsView setDelegate:self];    
        [self setPromotionView:newPromotionsView];
        [[self view] addSubview:promotionView];
        [newPromotionsView release];
    }
    [promotionView requestPromotion];    
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.promotionView = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction) donePressed:(id) sender {
    [self dismissModalViewControllerAnimated:YES];
}


#pragma mark - ACPromotionBannerView Delegates

// Sent when a promotion request has been successfully recieved. - If there were no promotions available number will be 0
- (void)acPromotionBannerViewDidReceivePromotion:(ACPromotionBannerView *)acPromotionView {
    NSLog(@"delegate - acPromotionViewDidReceivePromotion");
}

// Sent when a promotion request failed.  This is typically because no network connection was available. 
- (void)acPromotionBannerViewDidFailToReceivePromotion:(ACPromotionBannerView *)acPromotionView withError:(NSError *)error {
    NSLog(@"delegate - acPromotionBannerViewDidFailToReceivePromotion:%@", [error localizedDescription]);
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:nil otherButtonTitles: @"Close", nil];
    [alert show];
    [alert release];
}

- (void)acPromotionBannerViewDidClickOnPromotion:(ACPromotionBannerView *)acPromotionView {
    NSLog(@"delegate - acPromotionViewDidClickOnPromotion");
}


#pragma mark Promotion Wall Delegates

// Sent when a promotion request has been successfully recieved. - If there were no promotions available number will be 0
- (void)acPromotionWallDidReceivePromotions:(int)numberReceived {
    NSLog(@"delegate - acPromotionWallDidReceivePromotions numberReceived:%d", numberReceived);    
}

// Sent when a promotion request failed.  This is typically because no network connection was available. 
- (void)acPromotionWallDidFailToReceivePromotionsWithError:(NSError *)error {
    NSLog(@"delegate - acPromotionWallDidFailToReceivePromotionsWithError:%@", [error localizedDescription]);
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:nil otherButtonTitles: @"Close", nil];
    [alert show];
    [alert release];
}

// Sent just before dismissing a full screen promotions view 
- (void)acPromotionWallWillDismissScreen {
    NSLog(@"delegate - acPromotionWallWillDismissScreen");            
}

// Note: after this returns the app will end or go into the background
- (void)acPromotionWallDidClickOnPromotion {
    NSLog(@"delegate - acPromotionWallDidClickOnPromotion");            
}

#pragma mark Promotion Interstitial Delegates

// Sent when a promotion request has been successfully recieved. - If there were no promotions available number will be 0
- (void)acPromotionInterstitialDidReceivePromotion {
    NSLog(@"delegate - acPromotionInterstitialDidReceivePromotion");            
}

// Sent when a promotion request failed.  This is typically because no network connection was available. 
- (void)acPromotionInterstitialDidFailToReceiveWithError:(NSError *)error {
    NSLog(@"delegate - acPromotionInterstitialDidFailToReceiveWithError:%@", [error localizedDescription]);
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:nil otherButtonTitles: @"Close", nil];
    [alert show];
    [alert release];
}

- (void)acPromotionInterstitialWillDismissScreen {
    NSLog(@"delegate - acPromotionInterstitialWillDismissScreen");
}

- (void)acPromotionInterstitialDidClickOnPromotion {
    NSLog(@"delegate - acPromotionInterstitialDidClickOnPromotion");
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

@end
