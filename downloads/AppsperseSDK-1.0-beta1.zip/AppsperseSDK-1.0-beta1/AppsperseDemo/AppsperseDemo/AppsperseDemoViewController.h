//
//  AppsperseDemoViewController.h
//  AppsperseDemo
//
//  Created by Matthew Farnell on 10/30/11.
//  Copyright (c) 2011 MeMap. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ACPromotionBannerView.h"
#import "ACPromotionWall.h"
#import "ACPromotionInterstitial.h"


@interface AppsperseDemoViewController : UIViewController<ACPromotionBannerViewDelegate, ACPromotionWallDelegate, ACPromotionInterstitialDelegate> {
    
    ACPromotionBannerView* promotionView;    
}

@property (nonatomic, retain) ACPromotionBannerView* promotionView;

@end
