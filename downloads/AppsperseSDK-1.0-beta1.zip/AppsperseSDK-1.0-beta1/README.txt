Appsperse SDK version 1.0b1

1. Download the SDK

2. Copy the ACPromotion folder into your project
   Copy the JSONKit (if you don't already use it) folder into your project

3. Set the App Key kACAppKey in ACPromotionSettings.h

4. Add the QuartzCore.framework to your project.
(http://stackoverflow.com/questions/3352664/how-to-add-existing-frameworks-in-xcode-4)

Usage: 
(refer to AppsperseDemo project for example usage)

To show Promotion Wall

[[ACPromotionWall sharedACPromotionWall] showPromotions:self withDelegate:self];

To show Promotion Interstitial

[[ACPromotionInterstitial sharedACPromotionInterstitial] showInterstitial:self withDelegate:self];

To attach a banner view

ACPromotionBannerView *promotionsView = [[ACPromotionBannerView alloc] initWithPosition:CGPointMake(0, 0)];
[promotionsView setDelegate:self];    
[[self view] addSubview:promotionView];
[promotionView requestPromotion];    
