// Required Settings ***************************************************************

#define kACAppKey             @"REPLACE_THIS_TEXT_WITH_YOUR_APP_KEY"

// Optional Display settings - Uncomment to use. ***********************************

// ACPromotionBannerView Settings
//#define kACSettingsUseBannerGradient              true
//#define kACSettingsUseBannerBorder                true

// ACPromotionWall Settings
//#define kACSettingsWallTitle                      @"Recommended apps"
//#define kACSettingsWallBackgroundColor            ACRGBA(16, 200, 45, 1)
//#define kACSettingsWallNavigationBarTintColor     ACRGBA(16, 200, 45, 1)

// ACPromotionInterstitial Settings
//#define kACSettingsInterstitialText               @"Recommended app"
//#define kACSettingsInterstitialBackgroundColor    ACRGBA(16, 200, 45, 1)
//#define kACSettingsInterstitialBorderColor        ACRGBA(16, 200, 45, 1)

#define ACRGBA(r, g, b, a)    [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#import <Foundation/Foundation.h>

@interface ACPromotionSettings : NSObject

+ (NSString *)sdkVersion;

@end

