//
//  ACDemographics.h
//  AppsperseClient
//
//  Created by Hugo Troche on 11/1/11.
//  Copyright (c) 2011 Appsperse. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ACPromotionDemographics : NSObject

+ (void) trackHighValueMarker;
+ (void) trackHighValueMarker:(NSString *) markerLabel;

@end
