//
//  ACPromotion.h
//  AppsperseClient
//
//  Created by Matthew Farnell on 10/24/11.
//  (c) 2011 Appsperse. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ACPromotionWallDelegate <NSObject>

@optional

// Sent when a promotion request has been successfully recieved. - numberReceived will always be > 0. If no fill the error delegate below will be called.
- (void)acPromotionWallDidReceivePromotions:(int)numberReceived;

// Sent when a promotion request failed. This is typically because no network connection was available or no promotions were available (i.e. no fill).
- (void)acPromotionWallDidFailToReceivePromotionsWithError:(NSError *)error;

// Sent just before dismissing a full screen promotions view 
- (void)acPromotionWallWillDismissScreen;

// Note: after this returns the app will end or go into the background
- (void)acPromotionWallDidClickOnPromotion;

@end


@interface ACPromotionWall : NSObject {
    
}

@property (assign) id<ACPromotionWallDelegate> delegate;

+ (ACPromotionWall *)sharedACPromotionWall;

- (void)showPromotions:(UIViewController *)parentController withDelegate:(id<ACPromotionWallDelegate>)delegate;


@end
